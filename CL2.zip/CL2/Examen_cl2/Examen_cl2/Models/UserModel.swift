//
//  UserModel.swift
//  Examen_cl2
//
//  Created by Kevin on 6/27/21.
//  Copyright © 2021 Kevin. All rights reserved.
//

import Foundation

struct UserModel {
    var name:String
    var email:String
    var phone:String
    var gender:String
    var url:String
}
