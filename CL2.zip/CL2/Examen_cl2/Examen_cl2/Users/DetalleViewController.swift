//
//  DetalleViewController.swift
//  Examen_cl2
//
//  Created by Kevin on 6/27/21.
//  Copyright © 2021 Kevin. All rights reserved.
//

import UIKit
import AlamofireImage
import SwiftyJSON
import FirebaseFirestore

class DetalleViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    
    private let bd = Firestore.firestore()
    private let name:String
    private let email:String
    private let mobile:String
    private let gender:String
    private let url:String
    
    init(name: String,email:String,mobile: String, gender: String, url: String) {
        self.name = name
        self.email = email
        self.mobile = mobile
        self.gender = gender
        self.url = url
        super.init(nibName:nil,bundle:nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        nameLabel.text = name
        emailLabel.text = email
        mobileLabel.text = mobile
        genderLabel.text = gender
        
        //Alamofire.request(url).responseImage { (response) in
           // if let image = response.result.value {
               // DispatchQueue.main.async {
                 //   self.imageView.image = image
               // }
          //}
      // }
    }


}
