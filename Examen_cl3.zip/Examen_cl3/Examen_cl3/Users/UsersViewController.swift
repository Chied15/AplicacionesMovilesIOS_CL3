//
//  UsersViewController.swift
//  Examen_cl2
//
//  Created by Kevin on 6/27/21.
//  Copyright © 2021 Kevin. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class UsersViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var usersData: [UserModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 50
        self.tableView.register(UINib(nibName: "UserTableViewCell", bundle: nil), forCellReuseIdentifier: "userCell")
        
        fetchUserData()
    }

    func fetchUserData(){
        DispatchQueue.main.async {
            Alamofire.request("https://private-f56ceb-examen2.apiary-mock.com/contacts").responseJSON(completionHandler: {(response) in
                switch response.result{
                    
                case .success(let value):
                    let json = JSON(value)
                    let data = json
                    data["contacts"].array?.forEach({(contac) in
                        let contac = UserModel(name: contac["name"].stringValue,
                                               email:contac["email"].stringValue,
                                               phone:contac["mobile"].stringValue,
                                               gender:contac["gender"].stringValue,
                                               url:contac["url"].stringValue)
                        self.usersData.append(contac)
                    })
                    
                    self.tableView.reloadData()
                    
                case .failure(let error):
                    print(error.localizedDescription)
                }
            })
        }
    }
}


extension UsersViewController: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.usersData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell" ,for: indexPath) as! UserTableViewCell
        cell.nameLabel.text = self.usersData[indexPath.row].name
        cell.emailLabel.text = self.usersData[indexPath.row].email
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let indice = tableView.indexPathForSelectedRow!
        let name = self.usersData[indice.row].name
        let email = self.usersData[indice.row].email
        let phone = self.usersData[indice.row].phone
        let gender = self.usersData[indice.row].gender
        let img = self.usersData[indice.row].url
        self.navigationController?.pushViewController(DetalleViewController(name: name,email: email,mobile: phone,gender: gender,url: img), animated: true)
    }
    
    
    
}
