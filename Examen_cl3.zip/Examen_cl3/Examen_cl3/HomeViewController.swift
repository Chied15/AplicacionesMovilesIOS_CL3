//
//  HomeViewController.swift
//  Examen_cl2
//
//  Created by Kevin on 6/3/21.
//  Copyright © 2021 Kevin. All rights reserved.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

enum ProviderType : String {
    case basic
}

class HomeViewController: UIViewController {
    
    private let email: String
    private let provider: ProviderType
    
    private let db = Firestore.firestore()
    
    
    init(email: String , provider: ProviderType) {
        self.email = email
        self.provider = provider
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var providerLabel: UILabel!
    
    @IBOutlet weak var contactoButton: UIButton!
    @IBOutlet weak var closeSessionButtom: UIButton!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.setHidesBackButton(true, animated: false)
        
        emailLabel.text = email
        providerLabel.text = provider.rawValue
    }
    
    
    @IBAction func contactosButtonAction(_ sender: Any) {
        self.navigationController?.pushViewController(UsersViewController(), animated: true)
    }
    @IBAction func closeSessionButtomAction(_ sender: Any) {
        
        switch provider {
        case .basic:
            do{
                try Auth.auth().signOut()
                navigationController?.popViewController(animated: true)
            } catch{
                
            }
        }
    }
}
