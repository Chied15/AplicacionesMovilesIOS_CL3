//
//  ViewController.swift
//  Examen_cl2
//
//  Created by Kevin on 6/2/21.
//  Copyright © 2021 Kevin. All rights reserved.
//

import UIKit
import FirebaseAnalytics
import FirebaseAuth

class AuthViewController: UIViewController {
    
    @IBOutlet weak var emailTexField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    @IBOutlet weak var signUpBottom: UIButton!
    @IBOutlet weak var logInBottom: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    @IBAction func signUpBottom(_ sender: Any) {
        
        if let email = emailTexField.text, let password = passwordTextField.text {
            Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
                if let result = result , error == nil {
                    self.navigationController?
                    .pushViewController(HomeViewController (email: result.user.email!, provider: .basic), animated: true)
                    
                }else {
                    let alertcontroller = UIAlertController(title: "Aceptar", message: "Se ha producido un error registrando", preferredStyle: .alert)
                    alertcontroller.addAction(UIAlertAction(title: "Aceptar", style: .default))
                    self.present(alertcontroller, animated: true, completion: nil)
                }
                
            }
        }
    }
    

    @IBAction func logInBottom(_ sender: Any) {
        
        if let email = emailTexField.text, let password = passwordTextField.text {
            Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
                if let result = result , error == nil {
                    self.navigationController?
                        .pushViewController(HomeViewController (email: result.user.email!, provider: .basic), animated: true)
                    
                }else {
                    let alertcontroller = UIAlertController(title: "Aceptar", message: "Se ha producido un error registrando", preferredStyle: .alert)
                    alertcontroller.addAction(UIAlertAction(title: "Aceptar", style: .default))
                    self.present(alertcontroller, animated: true, completion: nil)
                }
                
            }
        }
    }
}

